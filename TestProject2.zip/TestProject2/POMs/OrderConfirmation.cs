﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using System.Threading;
using System;
namespace TestProject2.POMs
{
    class OrderConfirmation
    {
        private IWebDriver driver;

        public OrderConfirmation(IWebDriver driver)
        {

            this.driver = driver;

        }

        IWebElement Order => driver.FindElement(By.CssSelector(".order > strong"));
        IWebElement Accountclick => driver.FindElement(By.XPath("//ul[@id='menu-main']//a[@href='https://www.edgewordstraining.co.uk/demo-site/my-account/']"));

        public OrderConfirmation ()
        {

            Order.Click();
            //string Order = driver.FindElement(By.CssSelector(".order > strong")).Text;


        }


        public void OrderClick()
        {

            Accountclick.Click();
        }

    }





}}