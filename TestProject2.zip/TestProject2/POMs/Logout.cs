﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using System.Threading;
using System;
namespace TestProject2.POMs
{
    class Logout
    {
        private IWebDriver driver;

        public Logout(IWebDriver driver)
        {

            this.driver = driver;

        }

        IWebElement logout => driver.FindElement(By.LinkText("Logout"));


        public Logout ()
        {
            logout.Click();

        }





    }
}
