﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using System.Threading;
using System;
namespace TestProject2.POMs
{
    class AddDiscount
    {
        private IWebDriver driver;

        public AddDiscount(IWebDriver driver)
        {

            this.driver = driver;

        }


       
        IWebElement DiscountCode => driver.FindElement(By.Id("coupon_code"));
        IWebElement ClickButton => driver.FindElement(By.CssSelector("[name='apply_coupon']"));

        IWebElement Total => driver.FindElement(By.XPath("/html//article[@id='post-5']/div[@class='entry-content']/div[@class='woocommerce']//table[@class='shop_table shop_table_responsive']//tr[@class='cart-subtotal']/td/span"));

        IWebElement Subtotal => driver.FindElement(By.XPath("/html//article[@id='post-5']/div[@class='entry-content']//table[@class='shop_table shop_table_responsive']//tr[@class='order-total']//strong/span"));

        IWebElement Proceed => driver.FindElement(By.LinkText("Proceed to checkout"));
        public AddDiscount discount(string discountcode)
        {

            DiscountCode.Clear();
            DiscountCode.SendKeys("edgewords");
            return this;


        }
        public void buttonclick()
        {
            ClickButton.Click();
            Proceed.Click();

        }


    }
}
