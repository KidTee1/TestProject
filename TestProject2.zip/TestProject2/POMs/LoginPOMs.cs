﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using System.Threading;
using System;

namespace TestProject2.POMs
{


    public class LoginPOMs
    {
        private IWebDriver driver;

        public LoginPOMs(IWebDriver driver)
        {

            this.driver = driver;

        }


        // Points to the m
        // Closes the cookie tab
        IWebElement UserName => driver.FindElement(By.Id("username"));
        IWebElement Password => driver.FindElement(By.Id("password"));
        IWebElement LoginBtn => driver.FindElement(By.Name("login"));




        public LoginPOMs LoginMethods(string Username, string password)
        {

            UserName.Clear();
            Password.Clear();

            UserName.SendKeys("terell@gmail.com");
            Password.SendKeys("terell1234");


            return this;


        }
       public void LoginBtn1(){

             LoginBtn.Click();


            }







    }
    }
