﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using System.Threading;
using System;
namespace TestProject2.POMs
{
    class BillingDetails
    {
        private IWebDriver driver;

        public BillingDetails(IWebDriver driver)
        {

            this.driver = driver;

        }

        IWebElement Firstname => driver.FindElement(By.Id("billing_first_name"));//First 
        IWebElement Lastname => driver.FindElement(By.Id("billing_last_name"));//Last Name
        IWebElement Company => driver.FindElement(By.Id("billing_company"));//Company
        IWebElement Address => driver.FindElement(By.Id("billing_address_1"));//Address Line
        IWebElement Billinglastname => driver.FindElement(By.Id("billing_last_name"));//Apartment Name
        IWebElement Billingcity => driver.FindElement(By.Id("billing_city"));//City
        IWebElement BillingPostcode => driver.FindElement(By.Id("billing_postcode"));//Postcode
        IWebElement BillingPhone => driver.FindElement(By.Id("billing_phone"));

        IWebElement Placeorder => driver.FindElement(By.Name("woocommerce_checkout_place_order"));



        public BillingDetails Details()
        {

            Firstname.Clear();
            Lastname.Clear();
            Company.Clear();
            Address.Clear();
            Billinglastname.Clear();
            Billingcity.Clear();
            BillingPostcode.Clear();
            BillingPhone.Clear();

            Firstname.SendKeys("Terell");
            Lastname.SendKeys("Sijuwade");
            Company.SendKeys("NFocus");
            Address.SendKeys("1 Eastleigh Close");
            Billinglastname.SendKeys("Comber");
            Billingcity.SendKeys("London");
            BillingPostcode.SendKeys("NW2 7QN");
            BillingPhone.SendKeys("07891842594");

            return this;


        }

        public void Clicks() {

            Placeorder.Click();


            }





    }
}




