﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using System.Threading;
using System;
namespace TestProject2.POMs
{
    class AddCart
    {
        private IWebDriver driver;

        public AddCart(IWebDriver driver)
        {

            this.driver = driver;

        }


        // Points to the m
        // Closes the cookie tab
        IWebElement discount => driver.FindElement(By.CssSelector("[class='post-27 product type-product status-publish has-post-thumbnail product_cat-accessories first instock sale shipping-taxable purchasable product-type-simple'] .attachment-woocommerce_thumbnail"));
        IWebElement Addcart => driver.FindElement(By.CssSelector(".single_add_to_cart_button"));
        IWebElement ViewaCart => driver.FindElement(By.XPath("//ul[@id='site-header-cart']//a[@title='View your shopping cart']/span[@class='count']"));


        public void Clickshoplink()
        {
            ShopLink.Click();

        }

        public void ClickAddCart()
        {
            Addcart.Click();


        }

        public void ViewTheCart()
        {
            ViewaCart.Click();


        }










    }
}