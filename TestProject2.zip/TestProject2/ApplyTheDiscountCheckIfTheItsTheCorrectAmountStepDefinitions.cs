using System;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using System.Threading;
using System;

namespace TestProject2
{
  

    [Binding]
    public class ApplyTheDiscountCheckIfTheItsTheCorrectAmountStepDefinitions
    {
        IWebDriver driver;

      [Given(@"That the user has logged in with the correct details\.")]
        public void GivenThatTheUserHasLoggedInWithTheCorrectDetails_()
        {
            string baseUrl = "https://www.edgewordstraining.co.uk/demo-site/my-account/"; // Points to the m
            driver = new ChromeDriver(); //Object used to control 
            driver.Url = baseUrl;//Loads the url in the browser and allows us to automates aswell


            driver.FindElement(By.LinkText("Dismiss")).Click(); // Closes the cookie tab
            driver.FindElement(By.Id("username")).SendKeys("terell@gmail.com");// This allows QAs to type into the editable text field
            driver.FindElement(By.Id("password")).SendKeys("terell1234");// This allows QAs to type into the editable text field
            driver.FindElement(By.Name("login")).Click();//Emulates user Click on the element                                         
            Assert.That(driver.FindElement(By.LinkText("Log out")).Displayed);// Asserts and checks to see if the log out button is there.
            Console.WriteLine("Finished Login(Assert Passsed!");//Check point that prints finished log In

            Thread.Sleep(1000); //Pauses  for two seconds cause the system to wait a for the time 
            Console.WriteLine("Pause Succsesful");//Prints to System






        }

        [Given(@"User selects an item of their choice to their cart")]
        public void GivenUserSelectsAnItemOfTheirChoiceToTheirCart()
        {
            driver.FindElement(By.LinkText("Shop")).Click();
            Thread.Sleep(1000);//Thread Sleep that pauses the 


            //Clicks Image and adds to cart and then Applies discount
            driver.FindElement(By.CssSelector("[class='post-27 product type-product status-publish has-post-thumbnail product_cat-accessories first instock sale shipping-taxable purchasable product-type-simple'] .attachment-woocommerce_thumbnail")).Click();
            driver.FindElement(By.CssSelector(".single_add_to_cart_button")).Click();//Add Cart
            driver.FindElement(By.XPath("//ul[@id='site-header-cart']//a[@title='View your shopping cart']/span[@class='count']")).Click(); //View Cart
        }

        [Given(@"User Applies the discount code")]
        public void GivenUserAppliesTheDiscountCode()
        {
            driver.FindElement(By.Id("coupon_code")).SendKeys("edgewords");// Types Discount Code
                                                                           //Thread.Sleep(1000); // Thread Sleeps for one second 
            driver.FindElement(By.CssSelector("[name='apply_coupon']")).Click();
        }

        [Given(@"User Checks whether the discount is correct")]
        public void GivenUserChecksWhetherTheDiscountIsCorrect()
        {
            string text1 = driver.FindElement(By.XPath("/html//article[@id='post-5']/div[@class='entry-content']/div[@class='woocommerce']//table[@class='shop_table shop_table_responsive']//tr[@class='cart-subtotal']/td/span")).Text.Remove(0, 1);

            //Total
            string text3 = driver.FindElement(By.XPath("/html//article[@id='post-5']/div[@class='entry-content']//table[@class='shop_table shop_table_responsive']//tr[@class='order-total']//strong/span")).Text.Remove(0, 1);


            //Remove Pound Sign
            Console.WriteLine(text1 + "Pounds sign has been removed");


            //Total into double variable rounded
            double text5 = float.Parse(text3);
            Console.WriteLine(text5 + "       This Is the Total");

            double text2 = float.Parse(text1); //Converts into  float text2 = 342
            System.Console.WriteLine(text2 + "This is the subtotal"); //prints 342

            //Formula For The Percentage 
            double discount = (0.15 * text2);//Discount result 
            double discount2 = text2 - (text2 * 0.15);//Formula For Percentage
            double Result = discount2 + 3.95; // Adding The Shipping 


            System.Console.WriteLine(Result + "  This is meant to be the discount");


            //Is Result == Discount Displayed  try
            try
            {
                Assert.That(text5, Is.EqualTo(Result));
            }
            catch (Exception e)
            {
                Console.WriteLine("discount is not Applied");


            }
            driver.FindElement(By.LinkText("Proceed to checkout")).Click();
        }


        [Then(@"User Completes the billing details page")]
        public void ThenUserCompletesTheBillingDetailsPage()
        {
            driver.FindElement(By.Id("billing_first_name")).Clear();//First 
            driver.FindElement(By.Id("billing_last_name")).Clear();//Last Name
            driver.FindElement(By.Id("billing_company")).Clear();//Company
            driver.FindElement(By.Id("billing_address_1")).Clear();//Address Line
            driver.FindElement(By.Id("billing_last_name")).Clear();//Apartment Name
            driver.FindElement(By.Id("billing_city")).Clear();//City
            driver.FindElement(By.Id("billing_postcode")).Clear();//Postcode
            driver.FindElement(By.Id("billing_phone")).Clear();//Phone Number








            //System.Console.WriteLine(discount2 + " This is the Check point 2 Its been done ");
            Assert.That(driver.FindElement(By.Id("billing_first_name")).Displayed);

            var fname = driver.FindElement(By.Id("billing_first_name"));//Name
            var sname = driver.FindElement(By.Id("billing_last_name"));//Last Name
            var cname = driver.FindElement(By.Id("billing_company"));//Company
            var aname = driver.FindElement(By.Id("billing_address_1"));//Address Line
            var apartmentname = driver.FindElement(By.Id("billing_last_name"));//Apartment Name
            var tname = driver.FindElement(By.Id("billing_city"));//City
            var Addressname = driver.FindElement(By.Id("billing_postcode"));//Postcode
            var Phonename = driver.FindElement(By.Id("billing_phone"));//Phone



            //Form Details Here.
            fname.SendKeys("Terell");
            sname.SendKeys("Sijuwade");
            cname.SendKeys("NFocus");
            aname.SendKeys("1 Eastleigh Close");
            apartmentname.SendKeys("Comber");
            tname.SendKeys("London");
            Addressname.SendKeys("NW2 7QN");
            Phonename.SendKeys("07891842594");


            Thread.Sleep(2000);
            var Click = driver.FindElement(By.Name("woocommerce_checkout_place_order"));
            Click.Click();
        }

        [Then(@"Captures the order number on confimration page")]
        public void ThenCapturesTheOrderNumberOnConfimrationPage()
        {
            //Order Number Capture.
            Thread.Sleep(1000);
            string num = driver.FindElement(By.CssSelector(".order > strong")).Text;
            Thread.Sleep(1000);
            Console.WriteLine(num);
        }

        [Then(@"Checks if the order number is  displayed")]
        public void ThenChecksIfTheOrderNumberIsDisplayed()
        {
            Thread.Sleep(1000);
            var account = driver.FindElement(By.XPath("//ul[@id='menu-main']//a[@href='https://www.edgewordstraining.co.uk/demo-site/my-account/']"));
            Thread.Sleep(2000);
            account.Click();

            //Checks If Order Numbers Displayed
            driver.FindElement(By.LinkText("Orders")).Click();
            Assert.That(driver.FindElement(By.CssSelector("tr:nth-of-type(1) > .woocommerce-orders-table__cell.woocommerce-orders-table__cell-order-number > a")).Displayed);
            Console.WriteLine("Assert passed Order Number Displayed");
        }

        [Then(@"User logs Out")]
        public void ThenUserLogsOut()
        {
            var logout = driver.FindElement(By.LinkText("Logout"));
            logout.Click();
            Assert.That(driver.FindElement(By.Name("login")).Displayed);
        }
    }
}
